/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transfer;

/**
 *
 * @author user
 */
public enum Operacija {
    
    LOGIN,
    NOVI_KLIJENT_SE_PRIJAVIO,
    KLIJENT_SE_ODJAVIO,
    POSALJI_PORUKU_SVIM_KORISNICIMA,
    POSALJI_PORUKU_JEDNOM_KORISNIKU,
    PRIKAZI_PORUKE
    
}
