/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package komunikacija;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class Komunikacija {

    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    public Komunikacija(Socket socket) throws IOException {
        this.socket = socket;
        out = new ObjectOutputStream(socket.getOutputStream());
        out.reset();
        in = new ObjectInputStream(socket.getInputStream());
    }

    public Object procitaj() throws IOException, ClassNotFoundException {
        return in.readObject();
    }

    public void posalji(Object objekatZaSlanje) throws IOException {
        out.writeObject(objekatZaSlanje);
    }

    public void prekiniKomunikaciju() {
        try {
            socket.close();
        } catch (IOException ex) {
            Logger.getLogger(Komunikacija.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
