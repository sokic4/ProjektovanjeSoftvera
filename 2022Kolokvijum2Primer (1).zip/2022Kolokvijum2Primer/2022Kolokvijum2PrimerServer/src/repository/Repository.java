/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repository;

import java.util.ArrayList;
import java.util.List;
import model.Korisnik;

/**
 *
 * @author user
 */
public final class Repository {
    
    private static Repository instance;
    
    private List<Korisnik> korisnici = new ArrayList<>();

    private Repository() {
        korisnici.add(new Korisnik("K1-ime", "k1-prezime", "k1@gmail.com", "sifra1"));
        korisnici.add(new Korisnik("K2-ime", "k2-prezime", "k2@gmail.com", "sifra2"));
        korisnici.add(new Korisnik("K3-ime", "k3-prezime", "k3@gmail.com", "sifra3"));
        korisnici.add(new Korisnik("K4-ime", "k4-prezime", "k4@gmail.com", "sifra4"));
    }
    
    public static Repository getInstance() {
        if (instance == null) {
            instance = new Repository();
        }
        return instance;
    }

    public Korisnik login(String email, String sifra) {
        for (Korisnik k : korisnici) {
            if (k.getEmail().equals(email) && k.getSifra().equals(sifra)) {
                return k;
            }
        }
        return null;
    }
    
}
