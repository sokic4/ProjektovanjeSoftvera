/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thread;

import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import komunikacija.Komunikacija;
import model.Korisnik;
import repository.Repository;
import transfer.Operacija;
import transfer.Request;
import transfer.Response;

/**
 *
 * @author user
 */
public class KlijentNit extends Thread {

    private Komunikacija komunikacija;
    private ServerNit serverNit;
    private Korisnik korisnik;

    public KlijentNit(Socket socket, ServerNit serverNit) throws IOException {
        komunikacija = new Komunikacija(socket);
        this.serverNit = serverNit;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Request request = (Request) komunikacija.procitaj();
                obradiZahtev(request);
            }
        } catch (IOException ex) {
            prekiniKomunikaciju();
            serverNit.izbaciKlijentNit(this);
            String klijent = korisnik != null ? korisnik.getEmail() : "";
            System.out.println("Klijent " + klijent + " se diskonektovao");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KlijentNit.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void obradiZahtev(Request request) throws IOException {
        Response response = new Response();
        switch (request.getOperacija()) {
            case LOGIN:
                login(request, response);
                break;
            case POSALJI_PORUKU_SVIM_KORISNICIMA:
                posaljiPorukuSvimKorisnicima(request, response);
                break;
            case POSALJI_PORUKU_JEDNOM_KORISNIKU:
                posaljiPorukuJednomKorisniku(request, response);
                break;
            case PRIKAZI_PORUKE:
                prikaziPoruke(request, response);
                break;
            default:
                response.setGreska("Pogresna operacija");
                break;
        }
    }

    public void prekiniKomunikaciju() {
        komunikacija.prekiniKomunikaciju();
    }

    private void login(Request request, Response response) throws IOException {
        String email = (String) request.getData("email");
        String sifra = (String) request.getData("sifra");
        if (serverNit.jeKorisnikVecPrijavljen(email, sifra)) {
            response.setGreska("Korisnik je vec prijavljen");
        } else {
            korisnik = Repository.getInstance().login(email, sifra);
            if (korisnik != null) {
                response.putData("korisnik", korisnik);
            } else {
                response.setGreska("Invalid credentials");
            }
        }
        response.setOperacija(Operacija.LOGIN);
        komunikacija.posalji(response);
        serverNit.noviKlijentSePrijavio(this);
    }

    private void posaljiPorukuSvimKorisnicima(Request request, Response response) throws IOException {
        String poruka = (String) request.getData("poruka");
        Korisnik odKorisnika = (Korisnik) request.getData("odKorisnika");
        serverNit.posaljiPorukuSvimKlijentima(response, poruka, odKorisnika);
    }

    private void posaljiPorukuJednomKorisniku(Request request, Response response) {
        Korisnik odKorisnika = (Korisnik) request.getData("odKorisnika");
        Korisnik kaKorisniku = (Korisnik) request.getData("kaKorisniku");
        String poruka = (String) request.getData("poruka");
        try {
            serverNit.posaljiPorukuJednomKlijentu(odKorisnika, kaKorisniku, poruka);
        } catch (IOException ex) {
            Logger.getLogger(KlijentNit.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Korisnik getKorisnik() {
        return korisnik;
    }

    public Komunikacija getKomunikacija() {
        return komunikacija;
    }

    private void prikaziPoruke(Request request, Response response) {
        Korisnik odKorisnika = (Korisnik) request.getData("odKorisnika");
        Korisnik kaKorisniku = (Korisnik) request.getData("kaKorisniku");
        serverNit.prikaziPoruke(odKorisnika, kaKorisniku);
    }
    
}
