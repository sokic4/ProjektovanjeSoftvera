/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thread;

import form.ServerForm;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Korisnik;
import model.Poruka;
import transfer.Operacija;
import transfer.Response;

/**
 *
 * @author user
 */
public class ServerNit extends Thread {

    private ServerSocket serverSocket;
    private ServerForm serverForm;
    private List<KlijentNit> klijentNiti = new ArrayList<>();
    private List<Poruka> svePoruke = new ArrayList<>();

    public ServerNit(ServerForm serverForm) throws IOException {
        serverSocket = new ServerSocket(9000);
        this.serverForm = serverForm;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Socket socket = serverSocket.accept();
                poveziKlijenta(socket);
            }
        } catch (IOException ex) {
            System.out.println("Server zaustavljen");
        }
    }

    private void poveziKlijenta(Socket socket) {
        try {
            KlijentNit klijentNit = new KlijentNit(socket, this);
            klijentNiti.add(klijentNit);
            klijentNit.start();
        } catch (IOException ex) {
            Logger.getLogger(ServerNit.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void zaustaviServer() throws IOException {
        for (KlijentNit klijentNit : klijentNiti) {
            klijentNit.prekiniKomunikaciju();
        }
        serverSocket.close();
    }

    public synchronized void izbaciKlijentNit(KlijentNit klijentNit) {
        klijentNiti.remove(klijentNit);
        posaljiKorisnikeSvimKlijentima(Operacija.KLIJENT_SE_ODJAVIO);
    }

    public synchronized boolean jeKorisnikVecPrijavljen(String email, String sifra) {
        for (KlijentNit klijentNit : klijentNiti) {
            if (klijentNit.getKorisnik() != null
                    && klijentNit.getKorisnik().getEmail().equals(email)
                    && klijentNit.getKorisnik().getSifra().equals(sifra)) {
                return true;
            }
        }
        return false;
    }

    public synchronized void posaljiPorukuSvimKlijentima(Response response, String poruka, Korisnik odKorisnika) throws IOException {
        Poruka porukaZaSlanje = new Poruka(odKorisnika, null, poruka, LocalDateTime.now());
        svePoruke.add(porukaZaSlanje);
        for (KlijentNit klijentNit : klijentNiti) {
            response.setOperacija(Operacija.POSALJI_PORUKU_SVIM_KORISNICIMA);
            response.putData("poruka", porukaZaSlanje);
            klijentNit.getKomunikacija().posalji(response);
        }
    }

    public synchronized void noviKlijentSePrijavio(KlijentNit noviKlijent) throws IOException {
        posaljiKorisnikeSvimKlijentima(Operacija.NOVI_KLIJENT_SE_PRIJAVIO);
    }

    private void posaljiKorisnikeSvimKlijentima(Operacija operacija) {
        List<Korisnik> korisnici = new ArrayList<>();
        for (KlijentNit k : klijentNiti) {
            korisnici.add(k.getKorisnik());
        }
        for (KlijentNit k : klijentNiti) {
            Response response = new Response();
            response.setOperacija(operacija);
            response.putData("korisnici", korisnici);
            try {
                k.getKomunikacija().posalji(response);
            } catch (IOException ex) {
                Logger.getLogger(ServerNit.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public synchronized void posaljiPorukuJednomKlijentu(Korisnik odKorisnika, Korisnik kaKorisniku, String poruka) throws IOException {
        Poruka porukaZaSlanje = new Poruka(odKorisnika, null, poruka, LocalDateTime.now());
        svePoruke.add(porukaZaSlanje);
        for (KlijentNit k : klijentNiti) {
            if (k.getKorisnik().equals(kaKorisniku)) {
                Response response = new Response();
                response.setOperacija(Operacija.POSALJI_PORUKU_JEDNOM_KORISNIKU);
                response.putData("poruka", porukaZaSlanje);
                k.getKomunikacija().posalji(response);
                break;
            }
        }
    }

    public void prikaziPoruke(Korisnik odKorisnika, Korisnik kaKorisniku) {
        List<Poruka> porukeZaSlanje = new ArrayList<>();
        for (Poruka poruka : svePoruke) {
            if (odKorisnika.equals(poruka.getOdKorisnika()) && (poruka.getKaKorisniku() == null || kaKorisniku.equals(poruka.getKaKorisniku()))) {
                porukeZaSlanje.add(poruka);
            }
        }
        for (KlijentNit k : klijentNiti) {
            if (k.getKorisnik().equals(kaKorisniku)) {
                Response response = new Response();
                response.setOperacija(Operacija.PRIKAZI_PORUKE);
                response.putData("poruke", porukeZaSlanje);
                try {
                    k.getKomunikacija().posalji(response);
                } catch (IOException ex) {
                    Logger.getLogger(ServerNit.class.getName()).log(Level.SEVERE, null, ex);
                }
                break;
            }
        }
    }

}
