/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package form;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.Poruka;

/**
 *
 * @author user
 */
public class TableModelPoruke extends AbstractTableModel {

    private List<Poruka> poruke = new ArrayList<>();
    private String[] kolone = {"Od korisnika", "Za korisnika/Za sve", "Poruka"};
    private String[] koloneSaVremenom = { "Od korisnika", "Za korisnika/Za sve", "Poruka", "Vreme" };
    private TableModelPoruke tableModelOstalePoruke;
    private boolean limitTo3;
    private boolean showTime;

    public TableModelPoruke(boolean limitTo3, boolean showTime) {
        this.limitTo3 = limitTo3;
        this.showTime = showTime;
    }

    @Override
    public int getRowCount() {
        return poruke.size();
    }

    @Override
    public int getColumnCount() {
        return showTime ? koloneSaVremenom.length : kolone.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Poruka poruka = poruke.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return poruka.getOdKorisnika().getEmail();
            case 1:
                return poruka.getKaKorisniku() == null ? "Za sve" : poruka.getKaKorisniku().getEmail();
            case 2:
                return vratiSkracenuPoruku(poruka.getPoruka());
            case 3:
                return vratiVreme(poruka.getVreme());
            default:
                return "N/A";
        }
    }

    @Override
    public String getColumnName(int column) {
        return showTime ? koloneSaVremenom[column] : kolone[column];
    }

    private String vratiSkracenuPoruku(String poruka) {
        if (poruka.length() > 20) {
            return poruka.substring(0, 20) + "...";
        }
        return poruka;
    }

    public void addPoruka(Poruka poruka) {
        if (limitTo3 && poruke.size() == 3) {
            Poruka najranijaPoruka = poruke.get(0);
            poruke.remove(0);
            tableModelOstalePoruke.addPoruka(najranijaPoruka);
        }
        poruke.add(poruka);
        fireTableDataChanged();
    }

    public Poruka getPoruka(int rowIndex) {
        return poruke.get(rowIndex);
    }

    public void setTableModelPorukeOstalePoruke(TableModelPoruke tableModelOstalePoruke) {
        this.tableModelOstalePoruke = tableModelOstalePoruke;
    }

    private String vratiVreme(LocalDateTime vreme) {
        return vreme.getHour() + ":" + vreme.getMinute() + ":" + vreme.getSecond();
    }

}
