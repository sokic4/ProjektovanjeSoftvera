/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thread;

import form.GlavnaForma;
import form.LoginForm;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import komunikacija.Komunikacija;
import transfer.Response;

/**
 *
 * @author user
 */
public class NitZaCitanje extends Thread {

    private Komunikacija komunikacija;
    private LoginForm loginForm;
    private GlavnaForma glavnaForma;

    public NitZaCitanje(Komunikacija komunikacija, LoginForm loginForm) {
        this.komunikacija = komunikacija;
        this.loginForm = loginForm;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Response response = (Response) komunikacija.procitaj();
                obradiOdgovor(response);
            }
        } catch (IOException ex) {
            if (glavnaForma != null) {
                glavnaForma.logout();
                glavnaForma.dispose();
                prikaziLoginFormu();
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(NitZaCitanje.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void obradiOdgovor(Response response) {
        switch (response.getOperacija()) {
            case LOGIN:
                loginForm.login(response);
                break;
            case NOVI_KLIJENT_SE_PRIJAVIO:
                glavnaForma.azurirajKorisnike(response);
                break;
            case KLIJENT_SE_ODJAVIO:
                glavnaForma.azurirajKorisnike(response);
                break;
            case POSALJI_PORUKU_SVIM_KORISNICIMA:
                glavnaForma.posaljiPorukuSvimKlijentima(response);
                break;
            case POSALJI_PORUKU_JEDNOM_KORISNIKU:
                glavnaForma.posaljiPorukuJednomKlijentu(response);
                break;
            case PRIKAZI_PORUKE:
                glavnaForma.prikaziPoruke(response);
                break;
            default:
                JOptionPane.showMessageDialog(null, "Pogresna operacija");
                break;
        }
    }

    public void setGlavnaForma(GlavnaForma glavnaForma) {
        this.glavnaForma = glavnaForma;
    }

    private void prikaziLoginFormu() {
        LoginForm loginForm = new LoginForm();
        loginForm.setLocationRelativeTo(null);
        loginForm.setVisible(true);
    }

}
